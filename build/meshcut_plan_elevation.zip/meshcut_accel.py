"""Acceleration layer for MeshCut visibility tests."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Sequence

import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree

try:
    # Compiled optional module (built from cython/meshcut_parallel.pyx).
    from . import native_backend as _native_backend

    _cy_parallel = _native_backend.load_meshcut_parallel()
except Exception:  # pragma: no cover - Blender runtime dependent
    _cy_parallel = None


@dataclass
class VisibilityAcceleration:
    depsgraph: bpy.types.Depsgraph
    bvh: BVHTree | None
    tri_vertices: list[tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]]]


def cython_backend_available() -> bool:
    return _cy_parallel is not None


def _cython_required_error() -> RuntimeError:
    return RuntimeError(
        "Cython backend is required, but meshcut_parallel is not available. "
        "Build it with 'python -m pip install cython setuptools wheel', "
        "then run 'python setup.py build_ext --inplace' inside the cython folder "
        "and copy the generated meshcut_parallel binary into native_backend/."
    )


def build_visibility_acceleration(
    mesh_objects: Iterable[bpy.types.Object],
    depsgraph: bpy.types.Depsgraph,
    progress_callback: Callable[[float, str], None] | None = None,
):
    """Build BVH and flattened triangle data from evaluated meshes."""
    mesh_objects = list(mesh_objects)
    vertices: list[tuple[float, float, float]] = []
    polygons: list[tuple[int, int, int]] = []
    tri_vertices: list[tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]]] = []

    total_objects = max(1, len(mesh_objects))
    for index, obj in enumerate(mesh_objects):
        if progress_callback is not None:
            progress_callback(index / total_objects, f"Building visibility acceleration: {obj.name}")
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        if mesh is None:
            continue

        try:
            matrix = eval_obj.matrix_world
            base = len(vertices)

            for vert in mesh.vertices:
                world = matrix @ vert.co
                vertices.append((float(world.x), float(world.y), float(world.z)))

            mesh.calc_loop_triangles()
            for tri in mesh.loop_triangles:
                i0, i1, i2 = tri.vertices
                polygons.append((base + i0, base + i1, base + i2))
                tri_vertices.append((vertices[base + i0], vertices[base + i1], vertices[base + i2]))
        finally:
            eval_obj.to_mesh_clear()

    if not polygons:
        if progress_callback is not None:
            progress_callback(1.0, "Visibility acceleration not needed")
        return VisibilityAcceleration(depsgraph=depsgraph, bvh=None, tri_vertices=[])

    bvh = BVHTree.FromPolygons(vertices, polygons, all_triangles=True)
    if progress_callback is not None:
        progress_callback(1.0, "Visibility acceleration ready")
    return VisibilityAcceleration(depsgraph=depsgraph, bvh=bvh, tri_vertices=tri_vertices)


def visibility_mask(
    scene,
    accel: VisibilityAcceleration | None,
    origins: Sequence[Vector],
    directions: Sequence[Vector],
    distances: Sequence[float],
    epsilon: float = 1e-4,
    require_cython: bool = False,
):
    """Return a visibility boolean for each ray.

    Uses Cython parallel kernel when available. Falls back to BVH ray_cast and,
    as a last resort, Blender's scene.ray_cast.
    """
    if not origins:
        return []

    if require_cython and not cython_backend_available():
        raise _cython_required_error()

    if accel and accel.tri_vertices and _cy_parallel is not None:
        hit_distances = _cy_parallel.parallel_first_hit_distances(origins, directions, distances, accel.tri_vertices)
        return [hit < 0.0 or hit >= (dist - epsilon) for hit, dist in zip(hit_distances, distances)]

    bvh = accel.bvh if accel else None
    if bvh is not None:
        visible = []
        for origin, direction, dist in zip(origins, directions, distances):
            hit_loc, _normal, _index, _distance = bvh.ray_cast(origin, direction, dist + epsilon)
            if hit_loc is None:
                visible.append(True)
            else:
                hit_dist = (hit_loc - origin).length
                visible.append(hit_dist >= dist - epsilon)
        return visible

    visible = []
    depsgraph = accel.depsgraph if accel else bpy.context.evaluated_depsgraph_get()
    for origin, direction, dist in zip(origins, directions, distances):
        hit, location, _normal, _index, _obj, _matrix = scene.ray_cast(depsgraph, origin, direction, distance=dist + epsilon)
        if not hit:
            visible.append(True)
        else:
            visible.append((location - origin).length >= dist - epsilon)
    return visible
