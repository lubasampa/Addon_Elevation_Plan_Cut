﻿bl_info = {
    "name": "Mesh Cut Plan/Elevation",
    "author": "Luiz + Codex",
    "version": (2026, 4, 30),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Mesh Cut",
    "description": "Camera-based plan/elevation cuts for any mesh object with SVG/DXF export",
    "category": "Import-Export",
}

import math
import time
from pathlib import Path

import bpy
import gpu
import blf
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup, UIList
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from .meshcut_accel import build_visibility_acceleration, cython_backend_available, visibility_mask
from mathutils.geometry import intersect_line_plane

_DRAW_HANDLE_VIEW = None
_DRAW_HANDLE_TEXT = None
_DRAW_DIMENSION_PREVIEW = {
    "active": False,
    "segments": [],
    "label_pos": None,
    "label": "",
}


def _safe_name(name: str) -> str:
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in name)


def _get_or_create_meshcut_camera_collection(scene: bpy.types.Scene):
    collection_name = "MeshCut_Cameras"
    col = bpy.data.collections.get(collection_name)
    if col is None:
        col = bpy.data.collections.new(collection_name)
    if scene.collection.children.get(col.name) is None:
        scene.collection.children.link(col)
    return col


def _get_or_create_meshcut_annotation_collection(scene: bpy.types.Scene):
    collection_name = "MeshCut_Annotations"
    col = bpy.data.collections.get(collection_name)
    if col is None:
        col = bpy.data.collections.new(collection_name)
    if scene.collection.children.get(col.name) is None:
        scene.collection.children.link(col)
    return col


def _create_annotation_empty(scene: bpy.types.Scene, name: str, location: Vector):
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = "PLAIN_AXES"
    empty.empty_display_size = 0.15
    empty.location = location
    _get_or_create_meshcut_annotation_collection(scene).objects.link(empty)
    return empty


def _remove_annotation_object(obj_name: str):
    if not obj_name:
        return
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def _tag_redraw_view3d() -> None:
    wm = bpy.context.window_manager
    for window in wm.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _update_redraw(_self=None, _context=None):
    _tag_redraw_view3d()


def _tag_redraw_all_areas() -> None:
    wm = bpy.context.window_manager
    for window in wm.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            area.tag_redraw()


class _ProgressReporter:
    def __init__(self, context: bpy.types.Context, label: str):
        self._context = context
        self._label = label
        self._wm = getattr(context, "window_manager", None) or bpy.context.window_manager
        self._workspace = getattr(context, "workspace", None) or getattr(bpy.context, "workspace", None)
        self._window = getattr(context, "window", None) or getattr(bpy.context, "window", None)
        self._active = False
        self._last_value = -1
        self._last_redraw = 0.0
        self._last_status = ""
        self._scale = 1000

    def begin(self, text: str):
        if self._active:
            return
        self._wm.progress_begin(0, self._scale)
        self._active = True
        if self._window is not None:
            try:
                self._window.cursor_set("WAIT")
            except Exception:
                pass
        self.update(0.0, text, force=True)

    def update(self, fraction: float, text: str | None = None, force: bool = False):
        if not self._active:
            self.begin(text or self._label)
            return

        fraction = max(0.0, min(1.0, fraction))
        value = int(fraction * self._scale)
        now = time.monotonic()
        status_text = self._label if not text else f"{self._label}: {text}"
        if not force and value == self._last_value and status_text == self._last_status and (now - self._last_redraw) < 0.1:
            return

        self._wm.progress_update(value)
        if self._workspace is not None:
            try:
                self._workspace.status_text_set(status_text)
            except Exception:
                pass
        if force or (now - self._last_redraw) >= 0.1:
            _tag_redraw_all_areas()
            self._last_redraw = now
        self._last_value = value
        self._last_status = status_text

    def end(self):
        if not self._active:
            return
        self._wm.progress_end()
        if self._workspace is not None:
            try:
                self._workspace.status_text_set(None)
            except Exception:
                pass
        if self._window is not None:
            try:
                self._window.cursor_set("DEFAULT")
            except Exception:
                pass
        _tag_redraw_all_areas()
        self._active = False


def _camera_depth(local_point: Vector) -> float:
    return -local_point.z


def _clip_segment_depth(p1: Vector, p2: Vector, dmin: float, dmax: float):
    d1 = _camera_depth(p1)
    d2 = _camera_depth(p2)
    dd = d2 - d1
    t_enter = 0.0
    t_exit = 1.0

    if dd == 0.0:
        if d1 < dmin:
            return None
    else:
        t = (dmin - d1) / dd
        if dd > 0.0:
            t_enter = max(t_enter, t)
        else:
            t_exit = min(t_exit, t)

    if dd == 0.0:
        if d1 > dmax:
            return None
    else:
        t = (dmax - d1) / dd
        if dd > 0.0:
            t_exit = min(t_exit, t)
        else:
            t_enter = max(t_enter, t)

    if t_enter > t_exit:
        return None

    q1 = p1.lerp(p2, t_enter)
    q2 = p1.lerp(p2, t_exit)
    return q1, q2, t_enter, t_exit


def _project_point(camera: bpy.types.Object, local_point: Vector) -> tuple[float, float]:
    if camera.data.type == "PERSP":
        z = -local_point.z
        if z <= 1e-9:
            return 0.0, 0.0
        return local_point.x / z, local_point.y / z
    return local_point.x, local_point.y


def _resolve_export_context(context: bpy.types.Context):
    scene = getattr(context, "scene", None) or bpy.context.scene
    view_layer = getattr(context, "view_layer", None) or bpy.context.view_layer
    depsgraph = bpy.context.evaluated_depsgraph_get()
    return scene, view_layer, depsgraph


def _create_performance_budget(settings):
    visible_only = bool(getattr(settings, "visible_only", True))
    fallback_visible = bool(getattr(settings, "budget_fallback_visible", True))
    return {
        "enabled": bool(getattr(settings, "performance_guard", False)),
        "max_ray_casts": int(getattr(settings, "max_ray_casts", 200000)),
        "fallback_visible": fallback_visible and not visible_only,
        "force_visible_on_limit": bool(getattr(settings, "ensure_finish_on_budget", True)),
        "require_cython": bool(getattr(settings, "require_cython_backend", True)),
        "ray_casts": 0,
        "limit_hit": False,
    }


def _budget_returns_visible(budget) -> bool:
    return bool(budget and (budget.get("force_visible_on_limit") or budget.get("fallback_visible")))


def _reserve_ray_budget(budget, requested: int) -> int:
    if not budget or not budget["enabled"]:
        return requested

    remaining = budget["max_ray_casts"] - budget["ray_casts"]
    if remaining <= 0:
        budget["limit_hit"] = True
        return 0

    allowed = min(requested, remaining)
    budget["ray_casts"] += allowed
    if allowed < requested:
        budget["limit_hit"] = True
    return allowed


def _cython_requirement_message() -> str:
    return (
        "Require Cython Backend is enabled, but meshcut_parallel is missing. "
        "Build it with 'python -m pip install cython setuptools wheel' and "
        "'python setup.py build_ext --inplace' inside the cython folder, then "
        "copy the generated meshcut_parallel binary into native_backend/."
    )


def _ray_from_camera(camera, point_world: Vector, epsilon: float = 1e-4):
    if camera.data.type == "ORTHO":
        cam_inv = camera.matrix_world.inverted()
        p_cam = cam_inv @ point_world
        dist = -p_cam.z
        if dist <= epsilon:
            return None

        origin = camera.matrix_world @ Vector((p_cam.x, p_cam.y, 0.0))
        direction = camera.matrix_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))
        return origin, direction, dist

    origin = camera.matrix_world.translation
    ray = point_world - origin
    dist = ray.length
    if dist <= epsilon:
        return None
    direction = ray / dist
    return origin, direction, dist


def _is_world_point_visible(scene, depsgraph, camera, point_world: Vector, epsilon: float = 1e-4, budget=None, accel=None) -> bool:
    ray_data = _ray_from_camera(camera, point_world, epsilon=epsilon)
    if ray_data is None:
        return True

    allowed = _reserve_ray_budget(budget, 1)
    if allowed <= 0:
        return _budget_returns_visible(budget)

    origin, direction, dist = ray_data
    return visibility_mask(
        scene,
        accel,
        [origin],
        [direction],
        [dist],
        epsilon=epsilon,
        require_cython=bool(budget and budget.get("require_cython")),
    )[0]


def _visible_intervals_on_segment(scene, depsgraph, camera, p1_world: Vector, p2_world: Vector, samples: int, budget=None, accel=None):
    if budget and budget["enabled"] and budget["limit_hit"]:
        return [(0.0, 1.0)] if _budget_returns_visible(budget) else []

    samples = max(2, samples)
    requested_rays = samples + 1
    allowed_rays = _reserve_ray_budget(budget, requested_rays)
    if allowed_rays <= 0:
        return [(0.0, 1.0)] if _budget_returns_visible(budget) else []
    if allowed_rays < 2:
        return [(0.0, 1.0)] if _budget_returns_visible(budget) else []

    step = 1.0 / (allowed_rays - 1)
    vis_flags = [True] * allowed_rays
    batched_indices = []
    origins = []
    directions = []
    distances = []

    for i in range(allowed_rays):
        t = i * step
        ray_data = _ray_from_camera(camera, p1_world.lerp(p2_world, t))
        if ray_data is None:
            continue
        origin, direction, dist = ray_data
        batched_indices.append(i)
        origins.append(origin)
        directions.append(direction)
        distances.append(dist)

    if origins:
        batched_visibility = visibility_mask(
            scene,
            accel,
            origins,
            directions,
            distances,
            require_cython=bool(budget and budget.get("require_cython")),
        )
        for idx, visible in zip(batched_indices, batched_visibility):
            vis_flags[idx] = visible

    intervals = []
    t_start = None
    for i in range(allowed_rays):
        visible = vis_flags[i]
        t_cur = i * step
        if visible and t_start is None:
            t_start = t_cur
        if (not visible or i == allowed_rays - 1) and t_start is not None:
            t_end = t_cur if visible else max(0.0, t_cur - step)
            if t_end > t_start:
                intervals.append((t_start, t_end))
            t_start = None

    return intervals


def _camera_frame_corners_at_depth(camera, scene, depth: float):
    frame = camera.data.view_frame(scene=scene)
    corners_local = []

    if camera.data.type == "ORTHO":
        for c in frame:
            corners_local.append(Vector((c.x, c.y, -depth)))
    else:
        for c in frame:
            z = -c.z if abs(c.z) > 1e-9 else 1.0
            corners_local.append(c * (depth / z))

    mat = camera.matrix_world
    return [mat @ c for c in corners_local]


def _draw_loop_lines(coords, lines):
    for i in range(4):
        lines.extend((coords[i], coords[(i + 1) % 4]))


def _is_preview_camera_context(context, camera) -> bool:
    if not context or not context.region_data or not context.space_data:
        return False
    if context.space_data.type != "VIEW_3D":
        return False

    scene = context.scene
    settings = getattr(scene, "meshcut_settings", None)
    if settings is None:
        return False

    if settings.preview_only_camera_view:
        if context.region_data.view_perspective != "CAMERA":
            return False
        if scene.camera != camera:
            return False
    return True


def _draw_depth_overlay():
    context = bpy.context
    if not context or not context.scene:
        return

    scene = context.scene
    settings = getattr(scene, "meshcut_settings", None)
    if settings is None or not settings.show_depth_overlay:
        return

    camera = settings.camera_obj or scene.camera
    if not camera or camera.type != "CAMERA":
        return
    if not _is_preview_camera_context(context, camera):
        return

    dmin = max(0.0, min(settings.depth_near, settings.depth_far))
    dmax = max(settings.depth_near, settings.depth_far)

    near_corners = _camera_frame_corners_at_depth(camera, scene, dmin)
    far_corners = _camera_frame_corners_at_depth(camera, scene, dmax)

    near_lines = []
    far_lines = []
    side_lines = []
    _draw_loop_lines(near_corners, near_lines)
    _draw_loop_lines(far_corners, far_lines)
    for i in range(4):
        side_lines.extend((near_corners[i], far_corners[i]))

    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    gpu.state.depth_test_set("LESS_EQUAL")

    shader.bind()
    shader.uniform_float("color", (0.1, 1.0, 0.2, 0.9))
    batch_for_shader(shader, "LINES", {"pos": near_lines}).draw(shader)
    shader.uniform_float("color", (1.0, 0.6, 0.1, 0.9))
    batch_for_shader(shader, "LINES", {"pos": far_lines}).draw(shader)
    shader.uniform_float("color", (0.9, 0.9, 0.9, 0.35))
    batch_for_shader(shader, "LINES", {"pos": side_lines}).draw(shader)

    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")


def _format_length(scene, length: float) -> str:
    unit = scene.unit_settings.length_unit
    if unit in {"MILLIMETERS", "MILLIMETRES"}:
        return f"{length * 1000.0:.1f} mm"
    if unit in {"CENTIMETERS", "CENTIMETRES"}:
        return f"{length * 100.0:.2f} cm"
    if unit in {"METERS", "METRES", "NONE"}:
        return f"{length:.3f} m"
    return f"{length:.3f}"


def _camera_axes(camera: bpy.types.Object):
    quat = camera.matrix_world.to_quaternion()
    right = quat @ Vector((1.0, 0.0, 0.0))
    up = quat @ Vector((0.0, 1.0, 0.0))
    forward = quat @ Vector((0.0, 0.0, -1.0))
    return right.normalized(), up.normalized(), forward.normalized()


def _camera_cut_depth(settings) -> float:
    return max(0.0, min(float(settings.depth_near), float(settings.depth_far)))


def _camera_cut_plane_point(camera: bpy.types.Object, settings) -> Vector:
    _right, _up, forward = _camera_axes(camera)
    return camera.matrix_world.translation + (forward * _camera_cut_depth(settings))


def _project_world_to_camera_cut_plane(point: Vector, camera: bpy.types.Object, settings) -> Vector:
    right, up, _forward = _camera_axes(camera)
    plane_origin = _camera_cut_plane_point(camera, settings)
    offset = point - plane_origin
    return plane_origin + (right * offset.dot(right)) + (up * offset.dot(up))


def _constrain_dimension_point(p1: Vector, p2: Vector, mode: str, camera: bpy.types.Object) -> Vector:
    if mode not in {"HORIZONTAL", "VERTICAL"}:
        return p2

    right, up, _forward = _camera_axes(camera)
    delta = p2 - p1
    if mode == "HORIZONTAL":
        return p1 + (right * delta.dot(right))
    return p1 + (up * delta.dot(up))


def _mouse_to_camera_cut_plane(context: bpy.types.Context, event, camera: bpy.types.Object, settings):
    snap_point = _mouse_to_viewport_snap(context, event)
    if snap_point is not None:
        return _project_world_to_camera_cut_plane(snap_point, camera, settings)

    region = context.region
    if context.area is not None:
        window_regions = [reg for reg in context.area.regions if reg.type == "WINDOW"]
        if window_regions:
            region = window_regions[0]
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None

    coord = (event.mouse_x - region.x, event.mouse_y - region.y)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    ray_direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    plane_point = _camera_cut_plane_point(camera, settings)
    _right, _up, plane_normal = _camera_axes(camera)
    hit = intersect_line_plane(ray_origin, ray_origin + ray_direction, plane_point, plane_normal)
    if hit is None:
        return None
    return hit


def _viewport_event_data(context: bpy.types.Context, event):
    region = context.region
    if context.area is not None:
        window_regions = [reg for reg in context.area.regions if reg.type == "WINDOW"]
        if window_regions:
            region = window_regions[0]
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None, None, None

    return region, rv3d, Vector((event.mouse_x - region.x, event.mouse_y - region.y))


def _screen_distance_sq(region, rv3d, point: Vector, coord: Vector):
    p2d = view3d_utils.location_3d_to_region_2d(region, rv3d, point)
    if p2d is None:
        return None
    return (p2d - coord).length_squared


def _closest_screen_point_on_segment(region, rv3d, p1: Vector, p2: Vector, coord: Vector):
    s1 = view3d_utils.location_3d_to_region_2d(region, rv3d, p1)
    s2 = view3d_utils.location_3d_to_region_2d(region, rv3d, p2)
    if s1 is None or s2 is None:
        return None, None

    segment = s2 - s1
    length_sq = segment.length_squared
    if length_sq <= 1e-9:
        return p1, (s1 - coord).length_squared

    t = max(0.0, min(1.0, (coord - s1).dot(segment) / length_sq))
    return p1.lerp(p2, t), (s1.lerp(s2, t) - coord).length_squared


def _snap_elements_enabled(context: bpy.types.Context) -> set[str]:
    tool_settings = getattr(context.scene, "tool_settings", None)
    if tool_settings is None or not getattr(tool_settings, "use_snap", False):
        return set()

    elements = set(getattr(tool_settings, "snap_elements", set()) or set())
    if not elements:
        return {"VERTEX", "EDGE", "FACE"}
    return elements


def _mouse_to_viewport_snap(context: bpy.types.Context, event):
    region, rv3d, coord = _viewport_event_data(context, event)
    if region is None or rv3d is None:
        return None

    snap_elements = _snap_elements_enabled(context)
    snap_enabled = bool(snap_elements)
    threshold_px = 14.0 if snap_enabled else 8.0
    best_point = None
    best_dist_sq = threshold_px * threshold_px

    if snap_enabled and ({"VERTEX", "EDGE", "EDGE_MIDPOINT", "EDGE_PERPENDICULAR"} & snap_elements):
        depsgraph = context.evaluated_depsgraph_get()
        for obj in context.view_layer.objects:
            if obj.type != "MESH" or not obj.visible_get(view_layer=context.view_layer):
                continue

            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh()
            if mesh is None:
                continue
            try:
                matrix = eval_obj.matrix_world
                if "VERTEX" in snap_elements:
                    for vertex in mesh.vertices:
                        point = matrix @ vertex.co
                        dist_sq = _screen_distance_sq(region, rv3d, point, coord)
                        if dist_sq is not None and dist_sq < best_dist_sq:
                            best_point = point
                            best_dist_sq = dist_sq

                if {"EDGE", "EDGE_MIDPOINT", "EDGE_PERPENDICULAR"} & snap_elements:
                    vertices = mesh.vertices
                    for edge in mesh.edges:
                        p1 = matrix @ vertices[edge.vertices[0]].co
                        p2 = matrix @ vertices[edge.vertices[1]].co
                        if "EDGE_MIDPOINT" in snap_elements:
                            point = (p1 + p2) * 0.5
                            dist_sq = _screen_distance_sq(region, rv3d, point, coord)
                        else:
                            point, dist_sq = _closest_screen_point_on_segment(region, rv3d, p1, p2, coord)
                        if dist_sq is not None and dist_sq < best_dist_sq:
                            best_point = point
                            best_dist_sq = dist_sq
            finally:
                eval_obj.to_mesh_clear()

    if best_point is not None:
        return best_point

    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    ray_direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    hit, location, _normal, _index, obj, _matrix = context.scene.ray_cast(
        context.evaluated_depsgraph_get(),
        ray_origin,
        ray_direction,
    )
    if hit and obj is not None and obj.type == "MESH":
        if snap_enabled and "FACE" not in snap_elements:
            return None
        return location

    return None


def _point_camera_xy(camera: bpy.types.Object, point: Vector) -> tuple[float, float]:
    local = camera.matrix_world.inverted() @ point
    return local.x, local.y


def _world_from_camera_xy(camera: bpy.types.Object, settings, x: float, y: float) -> Vector:
    depth = _camera_cut_depth(settings)
    return camera.matrix_world @ Vector((x, y, -depth))


def _circle_from_3_points_2d(a, b, c):
    ax, ay = a
    bx, by = b
    cx, cy = c
    d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) <= 1e-9:
        return None

    aa = ax * ax + ay * ay
    bb = bx * bx + by * by
    cc = cx * cx + cy * cy
    ux = (aa * (by - cy) + bb * (cy - ay) + cc * (ay - by)) / d
    uy = (aa * (cx - bx) + bb * (ax - cx) + cc * (bx - ax)) / d
    radius = math.dist((ux, uy), a)
    if radius <= 1e-9:
        return None
    return (ux, uy), radius


def _angle_delta_ccw(start: float, end: float) -> float:
    return (end - start) % (math.pi * 2.0)


def _arc_camera_points(camera: bpy.types.Object, settings, p1: Vector, p2: Vector, p3: Vector, steps: int = 32):
    a = _point_camera_xy(camera, p1)
    b = _point_camera_xy(camera, p2)
    c = _point_camera_xy(camera, p3)
    circle = _circle_from_3_points_2d(a, b, c)
    if circle is None:
        return [p1, p3], (p1 + p3) * 0.5, (p3 - p1).length

    center, radius = circle
    start = math.atan2(a[1] - center[1], a[0] - center[0])
    mid = math.atan2(b[1] - center[1], b[0] - center[0])
    end = math.atan2(c[1] - center[1], c[0] - center[0])
    ccw_total = _angle_delta_ccw(start, end)
    ccw_mid = _angle_delta_ccw(start, mid)
    if ccw_mid <= ccw_total:
        total = ccw_total
    else:
        total = -_angle_delta_ccw(end, start)

    count = max(8, int(steps))
    points = []
    for index in range(count + 1):
        angle = start + (total * (index / count))
        x = center[0] + math.cos(angle) * radius
        y = center[1] + math.sin(angle) * radius
        points.append(_world_from_camera_xy(camera, settings, x, y))

    label_angle = start + (total * 0.5)
    label_pos = _world_from_camera_xy(
        camera,
        settings,
        center[0] + math.cos(label_angle) * radius,
        center[1] + math.sin(label_angle) * radius,
    )
    return points, label_pos, abs(total) * radius


def _segments_from_points(points):
    return [(points[index], points[index + 1]) for index in range(len(points) - 1)]


def _clear_dimension_preview():
    _DRAW_DIMENSION_PREVIEW["active"] = False
    _DRAW_DIMENSION_PREVIEW["segments"] = []
    _DRAW_DIMENSION_PREVIEW["label_pos"] = None
    _DRAW_DIMENSION_PREVIEW["label"] = ""
    _tag_redraw_view3d()


def _angle_radians(p1: Vector, pivot: Vector, p3: Vector):
    v1 = p1 - pivot
    v2 = p3 - pivot
    if v1.length <= 1e-9 or v2.length <= 1e-9:
        return None
    c = max(-1.0, min(1.0, v1.normalized().dot(v2.normalized())))
    return math.acos(c)


def _format_angle(p1: Vector, pivot: Vector, p3: Vector) -> str:
    angle = _angle_radians(p1, pivot, p3)
    if angle is None:
        return "0.00 deg"
    return f"{math.degrees(angle):.2f} deg"


def _angle_label_position(p1: Vector, pivot: Vector, p3: Vector) -> Vector:
    v1 = p1 - pivot
    v2 = p3 - pivot
    l1 = v1.length
    l2 = v2.length
    if l1 <= 1e-9 or l2 <= 1e-9:
        return pivot

    u1 = v1 / l1
    u2 = v2 / l2
    bis = u1 + u2
    if bis.length <= 1e-9:
        bis = u1

    radius = max(0.05, min(l1, l2) * 0.25)
    return pivot + bis.normalized() * radius


def _color_to_rgb255(color) -> tuple[int, int, int]:
    r = int(max(0.0, min(1.0, float(color[0]))) * 255.0)
    g = int(max(0.0, min(1.0, float(color[1]))) * 255.0)
    b = int(max(0.0, min(1.0, float(color[2]))) * 255.0)
    return r, g, b


def _color_to_svg(color) -> str:
    r, g, b = _color_to_rgb255(color)
    return f"#{r:02X}{g:02X}{b:02X}"


def _color_to_dxf_truecolor(color) -> int:
    r, g, b = _color_to_rgb255(color)
    return (r << 16) | (g << 8) | b


def _dxf_layer_name(name: str, fallback: str = "MESH") -> str:
    safe = "".join(c.upper() if c.isalnum() else "_" for c in (name or fallback))
    parts = [part for part in safe.split("_") if part]
    return "_".join(parts)[:255] or fallback


def _object_class_name(obj: bpy.types.Object) -> str:
    name = obj.name or "MESH"
    normalized = _dxf_layer_name(name, fallback="MESH")
    keywords = {
        "PAREDE": "PAREDE",
        "WALL": "PAREDE",
        "PROJETOR": "PROJETOR",
        "PROJETRO": "PROJETOR",
        "PROJETO": "PROJETOR",
    }
    for keyword, layer in keywords.items():
        if keyword in normalized:
            return layer

    base = name.split(".")[0]
    for separator in ("_", "-", " "):
        if separator in base:
            base = base.split(separator)[0]
            break
    return _dxf_layer_name(base, fallback="MESH")


def _object_projection_layer(obj: bpy.types.Object) -> str:
    return _object_class_name(obj)


def _object_section_layer(obj: bpy.types.Object) -> str:
    return f"{_object_class_name(obj)}_CORTE"


def _object_hatch_layer(obj: bpy.types.Object) -> str:
    return f"{_object_class_name(obj)}_HACHURA"


def _make_line(p1, p2, layer: str = "0", kind: str = "LINE"):
    return {"p1": p1, "p2": p2, "layer": _dxf_layer_name(layer, fallback="0"), "kind": kind}


def _make_point(point, layer: str = "0"):
    return {"point": point, "layer": _dxf_layer_name(layer, fallback="0")}


def _line_points(line):
    if isinstance(line, dict):
        return line["p1"], line["p2"]
    return line


def _point_xy(point):
    if isinstance(point, dict):
        return point["point"]
    return point


def _line_layer(line, fallback: str = "0") -> str:
    if isinstance(line, dict):
        return _dxf_layer_name(line.get("layer", fallback), fallback=fallback)
    return fallback


def _point_layer(point, fallback: str = "0") -> str:
    if isinstance(point, dict):
        return _dxf_layer_name(point.get("layer", fallback), fallback=fallback)
    return fallback


def _dedupe_points(points, epsilon: float = 1e-7):
    unique = []
    for point in points:
        if not any((point - existing).length <= epsilon for existing in unique):
            unique.append(point)
    return unique


def _triangle_section_segment(world_tri, cam_tri, cut_depth: float, epsilon: float = 1e-7):
    points = []
    depths = [_camera_depth(p_cam) for p_cam in cam_tri]
    offsets = [depth - cut_depth for depth in depths]

    if all(abs(offset) <= epsilon for offset in offsets):
        return None

    for index in range(3):
        next_index = (index + 1) % 3
        d1 = offsets[index]
        d2 = offsets[next_index]
        w1 = world_tri[index]
        w2 = world_tri[next_index]

        if abs(d1) <= epsilon:
            points.append(w1)
        if d1 * d2 < 0.0:
            t = abs(d1) / (abs(d1) + abs(d2))
            points.append(w1.lerp(w2, t))
        elif abs(d2) <= epsilon:
            points.append(w2)

    unique = _dedupe_points(points, epsilon=epsilon)
    if len(unique) < 2:
        return None
    return unique[0], unique[1]


def _snap_xy(point, precision: float = 1e-5):
    return (round(point[0] / precision), round(point[1] / precision))


def _loop_area(loop) -> float:
    area = 0.0
    for index, p1 in enumerate(loop):
        p2 = loop[(index + 1) % len(loop)]
        area += (p1[0] * p2[1]) - (p2[0] * p1[1])
    return area * 0.5


def _build_closed_loops_2d(segments, precision: float = 1e-5):
    adjacency = {}
    coords = {}
    edges = set()

    for p1, p2 in segments:
        k1 = _snap_xy(p1, precision)
        k2 = _snap_xy(p2, precision)
        if k1 == k2:
            continue
        edge = tuple(sorted((k1, k2)))
        if edge in edges:
            continue
        edges.add(edge)
        coords[k1] = p1
        coords[k2] = p2
        adjacency.setdefault(k1, []).append(k2)
        adjacency.setdefault(k2, []).append(k1)

    for key, neighbors in adjacency.items():
        neighbors.sort(key=lambda other: math.atan2(coords[other][1] - coords[key][1], coords[other][0] - coords[key][0]))

    visited_directed = set()
    loops = []

    for start in adjacency:
        for neighbor in adjacency[start]:
            if (start, neighbor) in visited_directed:
                continue

            loop_keys = [start]
            start_edge = (start, neighbor)
            cur = start
            nxt = neighbor

            while True:
                visited_directed.add((cur, nxt))
                prev, cur = cur, nxt
                if cur == start:
                    break
                loop_keys.append(cur)

                candidates = [candidate for candidate in adjacency.get(cur, []) if candidate != prev]
                if not candidates:
                    break

                incoming_angle = math.atan2(coords[prev][1] - coords[cur][1], coords[prev][0] - coords[cur][0])
                nxt = min(candidates, key=lambda candidate: (math.atan2(coords[candidate][1] - coords[cur][1], coords[candidate][0] - coords[cur][0]) - incoming_angle) % (math.pi * 2.0))

                if (cur, nxt) == start_edge or len(loop_keys) > len(adjacency) + 1:
                    break

            if cur == start and len(loop_keys) >= 3:
                loop = [coords[key] for key in loop_keys]
                if abs(_loop_area(loop)) > precision:
                    loops.append(loop)

    unique_loops = []
    seen = set()
    for loop in loops:
        keys = tuple(sorted(_snap_xy(point, precision) for point in loop))
        if keys in seen:
            continue
        seen.add(keys)
        unique_loops.append(loop)

    return unique_loops


def _rotate_xy(point, cos_a: float, sin_a: float):
    x, y = point
    return (x * cos_a - y * sin_a, x * sin_a + y * cos_a)


def _hatch_loop(loop, spacing: float, angle_degrees: float):
    if len(loop) < 3:
        return []

    angle = math.radians(angle_degrees)
    cos_a = math.cos(-angle)
    sin_a = math.sin(-angle)
    inv_cos = math.cos(angle)
    inv_sin = math.sin(angle)
    rotated = [_rotate_xy(point, cos_a, sin_a) for point in loop]
    ys = [point[1] for point in rotated]
    min_y = min(ys)
    max_y = max(ys)
    spacing = max(0.001, spacing)
    hatch_segments = []
    usable_height = max_y - min_y
    if usable_height <= 1e-9:
        return []

    if usable_height < spacing:
        hatch_rows = [(min_y + max_y) * 0.5]
    else:
        y = math.ceil((min_y + 1e-9) / spacing) * spacing
        if y >= max_y - 1e-9:
            y = (min_y + max_y) * 0.5
        hatch_rows = []
        while y < max_y - 1e-9:
            hatch_rows.append(y)
            y += spacing
        if not hatch_rows:
            hatch_rows.append((min_y + max_y) * 0.5)

    for y in hatch_rows:
        intersections = []
        for index, p1 in enumerate(rotated):
            p2 = rotated[(index + 1) % len(rotated)]
            x1, y1 = p1
            x2, y2 = p2
            if math.isclose(y1, y2):
                continue
            if (y1 <= y < y2) or (y2 <= y < y1):
                t = (y - y1) / (y2 - y1)
                intersections.append(x1 + ((x2 - x1) * t))

        intersections.sort()
        for index in range(0, len(intersections) - 1, 2):
            p1 = _rotate_xy((intersections[index], y), inv_cos, inv_sin)
            p2 = _rotate_xy((intersections[index + 1], y), inv_cos, inv_sin)
            if math.dist(p1, p2) > 1e-8:
                hatch_segments.append((p1, p2))

    return hatch_segments


def _hatch_segments_from_section(section_segments, spacing: float, angle_degrees: float):
    hatch_segments = []
    if not section_segments:
        return hatch_segments

    angle = math.radians(angle_degrees)
    cos_a = math.cos(-angle)
    sin_a = math.sin(-angle)
    inv_cos = math.cos(angle)
    inv_sin = math.sin(angle)
    rotated_segments = [(_rotate_xy(p1, cos_a, sin_a), _rotate_xy(p2, cos_a, sin_a)) for p1, p2 in section_segments]
    ys = [point[1] for segment in rotated_segments for point in segment]
    min_y = min(ys)
    max_y = max(ys)
    spacing = max(0.001, spacing)
    usable_height = max_y - min_y
    if usable_height <= 1e-9:
        return hatch_segments

    if usable_height < spacing:
        hatch_rows = [(min_y + max_y) * 0.5]
    else:
        y = math.ceil((min_y + 1e-9) / spacing) * spacing
        if y >= max_y - 1e-9:
            y = (min_y + max_y) * 0.5
        hatch_rows = []
        while y < max_y - 1e-9:
            hatch_rows.append(y)
            y += spacing
        if not hatch_rows:
            hatch_rows.append((min_y + max_y) * 0.5)

    for y in hatch_rows:
        intersections = []
        for p1, p2 in rotated_segments:
            x1, y1 = p1
            x2, y2 = p2
            if math.isclose(y1, y2):
                continue
            if (y1 <= y < y2) or (y2 <= y < y1):
                t = (y - y1) / (y2 - y1)
                intersections.append(x1 + ((x2 - x1) * t))

        intersections.sort()
        deduped = []
        for value in intersections:
            if not deduped or abs(value - deduped[-1]) > 1e-6:
                deduped.append(value)

        for index in range(0, len(deduped) - 1, 2):
            p1 = _rotate_xy((deduped[index], y), inv_cos, inv_sin)
            p2 = _rotate_xy((deduped[index + 1], y), inv_cos, inv_sin)
            if math.dist(p1, p2) > 1e-8:
                hatch_segments.append((p1, p2))

    if not hatch_segments:
        for loop in _build_closed_loops_2d(section_segments):
            hatch_segments.extend(_hatch_loop(loop, spacing, angle_degrees))
    return hatch_segments


def _section_depths_for_object(cam_verts, dmin: float, dmax: float, epsilon: float = 1e-7):
    if not cam_verts:
        return []
    depths = [_camera_depth(point) for point in cam_verts]
    obj_min = min(depths)
    obj_max = max(depths)
    cut_depths = []
    for depth in (dmin, dmax):
        if obj_min + epsilon < depth < obj_max - epsilon and not any(abs(depth - existing) <= epsilon for existing in cut_depths):
            cut_depths.append(depth)
    return cut_depths


def _sync_annotation_points_from_objects(ann):
    if ann.p1_object_name:
        obj1 = bpy.data.objects.get(ann.p1_object_name)
        if obj1 is not None:
            ann.p1 = obj1.matrix_world.translation
    if ann.p2_object_name:
        obj2 = bpy.data.objects.get(ann.p2_object_name)
        if obj2 is not None:
            ann.p2 = obj2.matrix_world.translation
    if ann.p3_object_name:
        obj3 = bpy.data.objects.get(ann.p3_object_name)
        if obj3 is not None:
            ann.p3 = obj3.matrix_world.translation

def _collect_annotation_world_geometry(scene, depsgraph, camera, settings, dmin: float, dmax: float, budget=None, accel=None, progress=None):
    cam_inv = camera.matrix_world.inverted()
    world_lines = []
    world_texts = []
    annotations = list(scene.meshcut_annotations)
    total_annotations = max(1, len(annotations))

    for index, ann in enumerate(annotations):
        if progress is not None:
            progress(index / total_annotations, f"Processing annotations: {ann.name or ann.text or ann.annotation_type}")
        _sync_annotation_points_from_objects(ann)
        p1_world = Vector(ann.p1)
        p1_cam = cam_inv @ p1_world

        if ann.annotation_type == "TEXT":
            depth = _camera_depth(p1_cam)
            if dmin <= depth <= dmax:
                world_texts.append((p1_world, ann.text.strip() or ann.name or "Note"))
            continue

        if ann.annotation_type == "ARC":
            p2_world = Vector(ann.p2)
            p3_world = Vector(ann.p3)
            arc_points, label_pos, arc_length = _arc_camera_points(camera, settings, p1_world, p2_world, p3_world)
            for w1, w2 in _segments_from_points(arc_points):
                world_lines.append((w1, w2))
            label = ann.text.strip() or _format_length(scene, arc_length)
            world_texts.append((label_pos, label))
            continue

        if ann.annotation_type == "ANGLE":
            pivot_world = Vector(ann.p2)
            p3_world = Vector(ann.p3)
            pivot_cam = cam_inv @ pivot_world
            p3_cam = cam_inv @ p3_world

            clipped1 = _clip_segment_depth(pivot_cam, p1_cam, dmin, dmax)
            clipped2 = _clip_segment_depth(pivot_cam, p3_cam, dmin, dmax)
            any_line = False

            for clipped in (clipped1, clipped2):
                if clipped is None:
                    continue
                _c1_cam, _c2_cam, t0, t1 = clipped
                c1_world = pivot_world.lerp(p1_world if clipped is clipped1 else p3_world, t0)
                c2_world = pivot_world.lerp(p1_world if clipped is clipped1 else p3_world, t1)

                vis_parts = [(0.0, 1.0)]

                for s0, s1 in vis_parts:
                    v1_world = c1_world.lerp(c2_world, s0)
                    v2_world = c1_world.lerp(c2_world, s1)
                    if (v2_world - v1_world).length > 1e-8:
                        world_lines.append((v1_world, v2_world))
                        any_line = True

            if any_line:
                label = ann.text.strip() or _format_angle(p1_world, pivot_world, p3_world)
                label_pos = _angle_label_position(p1_world, pivot_world, p3_world)
                depth = _camera_depth(cam_inv @ label_pos)
                if dmin <= depth <= dmax:
                    world_texts.append((label_pos, label))
            continue

        p2_world = Vector(ann.p2)
        p2_cam = cam_inv @ p2_world
        clipped = _clip_segment_depth(p1_cam, p2_cam, dmin, dmax)
        if clipped is None:
            continue

        c1_cam, c2_cam, t0, t1 = clipped
        c1_world = p1_world.lerp(p2_world, t0)
        c2_world = p1_world.lerp(p2_world, t1)

        vis_parts = [(0.0, 1.0)]

        any_line = False
        for s0, s1 in vis_parts:
            v1_world = c1_world.lerp(c2_world, s0)
            v2_world = c1_world.lerp(c2_world, s1)
            if (v2_world - v1_world).length > 1e-8:
                world_lines.append((v1_world, v2_world))
                any_line = True

        if any_line:
            label = ann.text.strip() or _format_length(scene, (c2_world - c1_world).length)
            mid_world = (c1_world + c2_world) * 0.5
            world_texts.append((mid_world, label))

    if progress is not None:
        progress(1.0, "Annotations ready")
    return world_lines, world_texts


def _collect_annotation_geometry(scene, depsgraph, camera, settings, dmin: float, dmax: float, budget=None, accel=None, progress=None):
    cam_inv = camera.matrix_world.inverted()
    world_lines, world_texts = _collect_annotation_world_geometry(
        scene,
        depsgraph,
        camera,
        settings,
        dmin,
        dmax,
        budget=budget,
        accel=accel,
        progress=progress,
    )
    anno_lines = []
    anno_texts = []

    for w1, w2 in world_lines:
        anno_lines.append((_project_point(camera, cam_inv @ w1), _project_point(camera, cam_inv @ w2)))

    for w, txt in world_texts:
        anno_texts.append((_project_point(camera, cam_inv @ w), txt))

    return anno_lines, anno_texts


def _collect_segments(context: bpy.types.Context, progress=None):
    scene, view_layer, depsgraph = _resolve_export_context(context)
    settings = scene.meshcut_settings
    camera = settings.camera_obj or scene.camera
    if not camera or camera.type != "CAMERA":
        raise RuntimeError("Pick a valid camera in Mesh Cut > Camera.")

    if settings.use_selected_only:
        mesh_objects = [obj for obj in view_layer.objects if obj.type == "MESH" and obj.select_get(view_layer=view_layer)]
    else:
        mesh_objects = [obj for obj in view_layer.objects if obj.type == "MESH" and obj.visible_get(view_layer=view_layer)]

    if not mesh_objects and len(scene.meshcut_annotations) == 0:
        if settings.use_selected_only:
            raise RuntimeError("No selected mesh objects found. Disable 'Selected Only' or select meshes.")
        raise RuntimeError("No visible mesh objects found for export.")

    cam_inv = camera.matrix_world.inverted()
    segments = []
    points = []
    budget = _create_performance_budget(settings)
    if budget["require_cython"] and not cython_backend_available():
        raise RuntimeError(_cython_requirement_message())
    if progress is not None:
        progress.update(0.02, "Preparing visibility acceleration", force=True)
    accel = build_visibility_acceleration(
        mesh_objects,
        depsgraph,
        progress_callback=(
            None
            if progress is None
            else lambda local_fraction, text: progress.update(0.02 + (0.18 * local_fraction), text)
        ),
    )

    dmin = min(settings.depth_near, settings.depth_far)
    dmax = max(settings.depth_near, settings.depth_far)
    mesh_work_total = 0
    for obj in mesh_objects:
        data = getattr(obj, "data", None)
        if data is None:
            continue
        if settings.export_vertices:
            mesh_work_total += len(data.vertices)
        mesh_work_total += len(data.edges)
    mesh_work_total = max(1, mesh_work_total)
    mesh_work_done = 0

    def _update_mesh_progress(detail: str, local_done: int = 0, force: bool = False):
        if progress is None:
            return
        fraction = (mesh_work_done + local_done) / mesh_work_total
        progress.update(0.20 + (0.68 * fraction), detail, force=force)

    for obj in mesh_objects:
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        if mesh is None:
            continue

        try:
            _update_mesh_progress(f"Tracing object: {obj.name}", force=True)
            projection_layer = _object_projection_layer(obj)
            section_layer = _object_section_layer(obj)
            hatch_layer = _object_hatch_layer(obj)
            world_mat = eval_obj.matrix_world
            world_verts = [world_mat @ v.co for v in mesh.vertices]
            cam_verts = [cam_inv @ p for p in world_verts]
            vertex_count = len(world_verts) if settings.export_vertices else 0
            edge_count = len(mesh.edges)

            if settings.export_section_cuts:
                mesh.calc_loop_triangles()
                for cut_depth in _section_depths_for_object(cam_verts, dmin, dmax):
                    object_section_segments = []
                    for tri in mesh.loop_triangles:
                        tri_indices = tri.vertices
                        world_tri = [world_verts[index] for index in tri_indices]
                        cam_tri = [cam_verts[index] for index in tri_indices]
                        section = _triangle_section_segment(world_tri, cam_tri, cut_depth)
                        if section is None:
                            continue
                        p1_world, p2_world = section
                        if (p2_world - p1_world).length <= 1e-8:
                            continue
                        p1_2d = _project_point(camera, cam_inv @ p1_world)
                        p2_2d = _project_point(camera, cam_inv @ p2_world)
                        object_section_segments.append((p1_2d, p2_2d))
                        segments.append(_make_line(p1_2d, p2_2d, section_layer, kind="SECTION"))

                    if settings.export_cut_hatches and object_section_segments:
                        for hatch_p1, hatch_p2 in _hatch_segments_from_section(object_section_segments, settings.hatch_spacing, settings.hatch_angle):
                            segments.append(_make_line(hatch_p1, hatch_p2, hatch_layer, kind="HATCH"))

            if settings.export_vertices:
                for vertex_index, (p_cam, p_world) in enumerate(zip(cam_verts, world_verts), start=1):
                    depth = _camera_depth(p_cam)
                    if dmin <= depth <= dmax:
                        if (not settings.visible_only) or _is_world_point_visible(scene, depsgraph, camera, p_world, budget=budget, accel=accel):
                            points.append(_make_point(_project_point(camera, p_cam), projection_layer))
                    if (vertex_index % 512) == 0:
                        _update_mesh_progress(f"Tracing vertices: {obj.name}", local_done=vertex_index)
                mesh_work_done += len(world_verts)

            for edge_index, edge in enumerate(mesh.edges, start=1):
                i1 = edge.vertices[0]
                i2 = edge.vertices[1]
                p1_cam = cam_verts[i1]
                p2_cam = cam_verts[i2]
                p1_world = world_verts[i1]
                p2_world = world_verts[i2]

                clipped = _clip_segment_depth(p1_cam, p2_cam, dmin, dmax)
                if clipped is None:
                    continue

                c1_cam, c2_cam, t0, t1 = clipped
                c1_world = p1_world.lerp(p2_world, t0)
                c2_world = p1_world.lerp(p2_world, t1)

                if not settings.visible_only:
                    segments.append(_make_line(_project_point(camera, c1_cam), _project_point(camera, c2_cam), projection_layer, kind="PROJECTION"))
                    continue

                intervals = _visible_intervals_on_segment(scene, depsgraph, camera, c1_world, c2_world, settings.visibility_samples, budget=budget, accel=accel)
                for s0, s1 in intervals:
                    v1_cam = c1_cam.lerp(c2_cam, s0)
                    v2_cam = c1_cam.lerp(c2_cam, s1)
                    if (v2_cam - v1_cam).length > 1e-8:
                        segments.append(_make_line(_project_point(camera, v1_cam), _project_point(camera, v2_cam), projection_layer, kind="PROJECTION"))
                if (edge_index % 256) == 0:
                    _update_mesh_progress(f"Tracing edges: {obj.name}", local_done=vertex_count + edge_index)
        finally:
            eval_obj.to_mesh_clear()
        mesh_work_done += edge_count
        _update_mesh_progress(f"Object complete: {obj.name}", force=True)

    if progress is not None:
        progress.update(0.90, "Projecting annotations", force=True)
    anno_lines, anno_texts = _collect_annotation_geometry(
        scene,
        depsgraph,
        camera,
        settings,
        dmin,
        dmax,
        budget=budget,
        accel=accel,
        progress=(
            None
            if progress is None
            else lambda local_fraction, text: progress.update(0.90 + (0.08 * local_fraction), text)
        ),
    )

    if not segments and not points and not anno_lines and not anno_texts:
        raise RuntimeError("Nothing to export with current depth settings.")

    if progress is not None:
        progress.update(0.98, "Finalizing export data", force=True)
    return segments, points, anno_lines, anno_texts, budget


def _draw_annotations_overlay_view():
    context = bpy.context
    if not context or not context.scene:
        return

    scene = context.scene
    settings = getattr(scene, "meshcut_settings", None)
    if settings is None or not settings.show_annotation_preview:
        return

    camera = settings.camera_obj or scene.camera
    if not camera or camera.type != "CAMERA":
        return
    if not _is_preview_camera_context(context, camera):
        return

    depsgraph = context.evaluated_depsgraph_get()
    dmin = min(settings.depth_near, settings.depth_far)
    dmax = max(settings.depth_near, settings.depth_far)
    preview_meshes = [obj for obj in context.view_layer.objects if obj.type == "MESH" and obj.visible_get(view_layer=context.view_layer)]
    accel = build_visibility_acceleration(preview_meshes, depsgraph)
    world_lines, _world_texts = _collect_annotation_world_geometry(scene, depsgraph, camera, settings, dmin, dmax, accel=accel)

    if not world_lines and not _DRAW_DIMENSION_PREVIEW["active"]:
        return

    line_vertices = []
    for w1, w2 in world_lines:
        line_vertices.extend((w1, w2))

    if _DRAW_DIMENSION_PREVIEW["active"]:
        for p1, p2 in _DRAW_DIMENSION_PREVIEW["segments"]:
            line_vertices.extend((p1, p2))

    if not line_vertices:
        return

    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    gpu.state.depth_test_set("NONE" if settings.annotation_on_top else "LESS_EQUAL")
    shader.bind()
    shader.uniform_float("color", tuple(settings.annotation_line_color))
    batch_for_shader(shader, "LINES", {"pos": line_vertices}).draw(shader)
    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")


def _draw_annotations_overlay_text():
    context = bpy.context
    if not context or not context.scene or not context.region or not context.region_data:
        return

    scene = context.scene
    settings = getattr(scene, "meshcut_settings", None)
    if settings is None or not settings.show_annotation_preview:
        return

    camera = settings.camera_obj or scene.camera
    if not camera or camera.type != "CAMERA":
        return
    if not _is_preview_camera_context(context, camera):
        return

    depsgraph = context.evaluated_depsgraph_get()
    dmin = min(settings.depth_near, settings.depth_far)
    dmax = max(settings.depth_near, settings.depth_far)
    preview_meshes = [obj for obj in context.view_layer.objects if obj.type == "MESH" and obj.visible_get(view_layer=context.view_layer)]
    accel = build_visibility_acceleration(preview_meshes, depsgraph)
    _world_lines, world_texts = _collect_annotation_world_geometry(scene, depsgraph, camera, settings, dmin, dmax, accel=accel)

    font_id = 0
    blf.size(font_id, int(max(8, settings.viewport_text_size)))
    blf.color(font_id, *tuple(settings.annotation_text_color))

    for wpos, txt in world_texts:
        p2d = view3d_utils.location_3d_to_region_2d(context.region, context.region_data, wpos)
        if p2d:
            blf.position(font_id, p2d.x + 4.0, p2d.y + 4.0, 0)
            blf.draw(font_id, txt)

    if _DRAW_DIMENSION_PREVIEW["active"] and _DRAW_DIMENSION_PREVIEW["label_pos"]:
        p2d = view3d_utils.location_3d_to_region_2d(context.region, context.region_data, _DRAW_DIMENSION_PREVIEW["label_pos"])
        if p2d:
            blf.position(font_id, p2d.x + 4.0, p2d.y + 4.0, 0)
            blf.draw(font_id, _DRAW_DIMENSION_PREVIEW["label"])


def _draw_view_overlay():
    _draw_depth_overlay()
    _draw_annotations_overlay_view()

def _bounds_2d(segments, points, anno_lines, anno_texts):
    xs = []
    ys = []

    for line in segments:
        (x1, y1), (x2, y2) = _line_points(line)
        xs.extend((x1, x2))
        ys.extend((y1, y2))

    for line in anno_lines:
        (x1, y1), (x2, y2) = _line_points(line)
        xs.extend((x1, x2))
        ys.extend((y1, y2))

    for point in points:
        x, y = _point_xy(point)
        xs.append(x)
        ys.append(y)

    for (x, y), _txt in anno_texts:
        xs.append(x)
        ys.append(y)

    if not xs:
        return 0.0, 0.0, 1.0, 1.0

    min_x = min(xs)
    min_y = min(ys)
    max_x = max(xs)
    max_y = max(ys)

    if math.isclose(min_x, max_x):
        max_x += 1.0
    if math.isclose(min_y, max_y):
        max_y += 1.0

    return min_x, min_y, max_x, max_y


def _write_svg(filepath: str, segments, points, anno_lines, anno_texts, scale: float, margin: float, text_size: float, anno_line_color, anno_text_color):
    min_x, min_y, max_x, max_y = _bounds_2d(segments, points, anno_lines, anno_texts)
    width = (max_x - min_x) * scale + (2.0 * margin)
    height = (max_y - min_y) * scale + (2.0 * margin)

    def map_xy(x, y):
        sx = (x - min_x) * scale + margin
        sy = (max_y - y) * scale + margin
        return sx, sy

    lines = []
    lines.append('<?xml version="1.0" encoding="UTF-8" standalone="no"?>')
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="{width:.4f}" height="{height:.4f}" viewBox="0 0 {width:.4f} {height:.4f}">')
    lines.append('<g stroke="black" fill="none" stroke-width="1">')

    for line in segments:
        (x1, y1), (x2, y2) = _line_points(line)
        sx1, sy1 = map_xy(x1, y1)
        sx2, sy2 = map_xy(x2, y2)
        lines.append(f'<line x1="{sx1:.4f}" y1="{sy1:.4f}" x2="{sx2:.4f}" y2="{sy2:.4f}" />')

    lines.append("</g>")

    if points:
        lines.append('<g fill="red" stroke="none">')
        for point in points:
            x, y = _point_xy(point)
            sx, sy = map_xy(x, y)
            lines.append(f'<circle cx="{sx:.4f}" cy="{sy:.4f}" r="1.5" />')
        lines.append("</g>")

    if anno_lines:
        stroke = _color_to_svg(anno_line_color)
        stroke_opacity = max(0.0, min(1.0, float(anno_line_color[3])))
        lines.append(f'<g stroke="{stroke}" stroke-opacity="{stroke_opacity:.4f}" fill="none" stroke-width="1.2">')
        for line in anno_lines:
            (x1, y1), (x2, y2) = _line_points(line)
            sx1, sy1 = map_xy(x1, y1)
            sx2, sy2 = map_xy(x2, y2)
            lines.append(f'<line x1="{sx1:.4f}" y1="{sy1:.4f}" x2="{sx2:.4f}" y2="{sy2:.4f}" />')
        lines.append("</g>")

    if anno_texts:
        fill = _color_to_svg(anno_text_color)
        fill_opacity = max(0.0, min(1.0, float(anno_text_color[3])))
        lines.append(f'<g fill="{fill}" fill-opacity="{fill_opacity:.4f}" stroke="none">')
        for (x, y), txt in anno_texts:
            sx, sy = map_xy(x, y)
            safe_txt = txt.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            lines.append(f'<text x="{sx:.4f}" y="{sy:.4f}" font-size="{text_size:.2f}">{safe_txt}</text>')
        lines.append("</g>")

    lines.append("</svg>")
    Path(filepath).write_text("\n".join(lines), encoding="utf-8")

def _collect_dxf_layers(segments, points, anno_lines, anno_texts):
    layers = {"0", "ANNOTATIONS"}
    for line in segments:
        layers.add(_line_layer(line))
    for point in points:
        layers.add(_point_layer(point))
    for _line in anno_lines:
        layers.add("ANNOTATIONS")
    for _text in anno_texts:
        layers.add("ANNOTATIONS")
    return sorted(layers)


def _write_dxf(filepath: str, segments, points, anno_lines, anno_texts, text_height: float, anno_line_color, anno_text_color):
    dxf_layers = _collect_dxf_layers(segments, points, anno_lines, anno_texts)
    lines = ["0", "SECTION", "2", "HEADER", "0", "ENDSEC", "0", "SECTION", "2", "TABLES", "0", "TABLE", "2", "LAYER", "70", str(len(dxf_layers))]
    for layer in dxf_layers:
        lines.extend(["0", "LAYER", "2", layer, "70", "0", "62", "7", "6", "CONTINUOUS"])
    lines.extend(["0", "ENDTAB", "0", "ENDSEC", "0", "SECTION", "2", "ENTITIES"])
    line_truecolor = str(_color_to_dxf_truecolor(anno_line_color))
    text_truecolor = str(_color_to_dxf_truecolor(anno_text_color))

    for line in segments:
        (x1, y1), (x2, y2) = _line_points(line)
        lines.extend(["0", "LINE", "8", _line_layer(line), "10", f"{x1:.6f}", "20", f"{y1:.6f}", "30", "0.0", "11", f"{x2:.6f}", "21", f"{y2:.6f}", "31", "0.0"])

    for line in anno_lines:
        (x1, y1), (x2, y2) = _line_points(line)
        lines.extend(["0", "LINE", "8", "ANNOTATIONS", "420", line_truecolor, "10", f"{x1:.6f}", "20", f"{y1:.6f}", "30", "0.0", "11", f"{x2:.6f}", "21", f"{y2:.6f}", "31", "0.0"])

    for point in points:
        x, y = _point_xy(point)
        lines.extend(["0", "POINT", "8", _point_layer(point), "10", f"{x:.6f}", "20", f"{y:.6f}", "30", "0.0"])

    for (x, y), txt in anno_texts:
        lines.extend(["0", "TEXT", "8", "ANNOTATIONS", "420", text_truecolor, "10", f"{x:.6f}", "20", f"{y:.6f}", "30", "0.0", "40", f"{text_height:.6f}", "1", txt])

    lines.extend(["0", "ENDSEC", "0", "EOF"])
    Path(filepath).write_text("\n".join(lines), encoding="ascii", errors="ignore")


def _get_dimension_points_from_context(context: bpy.types.Context):
    obj = context.active_object

    if context.mode == "EDIT_MESH" and obj and obj.type == "MESH":
        import bmesh

        bm = bmesh.from_edit_mesh(obj.data)
        verts = [v for v in bm.verts if v.select]
        if len(verts) == 2:
            return obj.matrix_world @ verts[0].co, obj.matrix_world @ verts[1].co, None

    selected = [o for o in context.selected_objects if o.type in {"MESH", "EMPTY", "CURVE", "FONT", "LIGHT", "CAMERA"}]
    if len(selected) >= 2:
        return selected[0].matrix_world.translation.copy(), selected[1].matrix_world.translation.copy(), None

    return None, None, "Select 2 vertices in Edit Mode or 2 objects in Object Mode."


def _get_angle_points_from_context(context: bpy.types.Context):
    obj = context.active_object

    if context.mode == "EDIT_MESH" and obj and obj.type == "MESH":
        import bmesh

        bm = bmesh.from_edit_mesh(obj.data)
        verts = [v for v in bm.verts if v.select]
        if len(verts) == 3:
            return (
                obj.matrix_world @ verts[0].co,
                obj.matrix_world @ verts[1].co,
                obj.matrix_world @ verts[2].co,
                None,
            )

    selected = [o for o in context.selected_objects if o.type in {"MESH", "EMPTY", "CURVE", "FONT", "LIGHT", "CAMERA"}]
    if len(selected) >= 3:
        return selected[0].matrix_world.translation.copy(), selected[1].matrix_world.translation.copy(), selected[2].matrix_world.translation.copy(), None

    return None, None, None, "Select 3 vertices in Edit Mode or 3 objects in Object Mode."


class MESHCUT_PG_annotation(PropertyGroup):
    annotation_type: EnumProperty(
        name="Type",
        items=[
            ("TEXT", "Text", "Text note"),
            ("DIMENSION", "Dimension", "Distance dimension"),
            ("ANGLE", "Angle", "Angle dimension with 3 points"),
            ("ARC", "Arc", "Arc length dimension with 3 points"),
        ],
        default="TEXT",
    )
    text: StringProperty(name="Text", default="")
    p1: FloatVectorProperty(name="P1", size=3, subtype="TRANSLATION", default=(0.0, 0.0, 0.0))
    p2: FloatVectorProperty(name="P2", size=3, subtype="TRANSLATION", default=(0.0, 0.0, 0.0))
    p3: FloatVectorProperty(name="P3", size=3, subtype="TRANSLATION", default=(0.0, 0.0, 0.0))
    p1_object_name: StringProperty(name="P1 Object", default="")
    p2_object_name: StringProperty(name="P2 Object", default="")
    p3_object_name: StringProperty(name="P3 Object", default="")


class MESHCUT_PG_settings(PropertyGroup):
    use_selected_only: BoolProperty(name="Selected Only", description="Export only selected mesh objects", default=True)
    export_vertices: BoolProperty(name="Export Vertices", description="Include vertices as points in SVG and DXF", default=True)
    visible_only: BoolProperty(name="Visible Only (No X-Ray)", description="Cast rays from camera and keep only directly visible geometry", default=True)
    performance_guard: BoolProperty(name="Performance Guard", description="Limit ray-casts to avoid Blender freezes on heavy scenes", default=True)
    max_ray_casts: IntProperty(name="Max Ray Casts", description="Maximum visibility tests per export", default=150000, min=1000, max=10000000, soft_max=1000000)
    require_cython_backend: BoolProperty(name="Require Cython Backend", description="Fail export unless the compiled meshcut_parallel backend is available", default=True)
    ensure_finish_on_budget: BoolProperty(name="Always Finish Export", description="When the ray budget is exhausted, keep the remaining geometry visible so DXF/SVG export still completes", default=True)
    budget_fallback_visible: BoolProperty(name="Fallback To Visible", description="When limit is reached, keep remaining geometry visible instead of skipping (ignored when Visible Only is enabled)", default=False)
    visibility_samples: IntProperty(
        name="Visibility Samples",
        description="Samples per edge for hidden-line filtering (higher = cleaner, slower)",
        default=64,
        min=2,
        max=2048,
        soft_max=512,
    )
    show_depth_overlay: BoolProperty(name="Show Near/Far Overlay", description="Draw depth range box in viewport", default=True, update=_update_redraw)
    depth_near: FloatProperty(name="Depth Near", description="Minimum depth from camera", default=0.0, min=0.0, soft_max=1000.0, update=_update_redraw)
    depth_far: FloatProperty(name="Depth Far", description="Maximum depth from camera", default=100.0, min=0.0, soft_max=1000.0, update=_update_redraw)
    export_section_cuts: BoolProperty(name="Export Cut Edges", description="Create real section lines where mesh faces cross the near cut plane", default=True)
    export_cut_hatches: BoolProperty(name="Export Cut Hatches", description="Create hatch lines inside closed section contours", default=True)
    hatch_spacing: FloatProperty(name="Hatch Spacing", description="Distance between generated hatch lines in DXF/SVG units", default=0.25, min=0.001, soft_max=100.0)
    hatch_angle: FloatProperty(name="Hatch Angle", description="Hatch angle in degrees", default=45.0, min=-180.0, max=180.0)
    svg_scale: FloatProperty(name="SVG Scale", description="SVG scale", default=100.0, min=0.001, soft_max=10000.0)
    svg_margin: FloatProperty(name="SVG Margin", description="SVG margin", default=20.0, min=0.0, soft_max=1000.0)
    svg_text_size: FloatProperty(name="SVG Text Size", description="Text size in SVG pixels", default=12.0, min=1.0, soft_max=200.0)
    dxf_text_height: FloatProperty(name="DXF Text Height", description="Text height in DXF units", default=0.2, min=0.0001, soft_max=1000.0)
    new_text_label: StringProperty(name="New Text", description="Text used for new note", default="Note")
    new_dim_label: StringProperty(name="Dimension Label", description="Custom label for new dimensions (empty = auto length)", default="")
    dimension_mode: EnumProperty(
        name="Measure Mode",
        description="Constraint used by the viewport measure tool",
        items=[
            ("LINEAR", "Linear", "Measure a straight 2-point distance"),
            ("ALIGNED", "Aligned", "Measure the direct distance between two points"),
            ("HORIZONTAL", "Horizontal", "Measure only along the camera horizontal axis"),
            ("VERTICAL", "Vertical", "Measure only along the camera vertical axis"),
            ("ARC", "Arc", "Measure an arc from three clicked points"),
        ],
        default="LINEAR",
    )
    dimension_default_length: FloatProperty(name="Dimension Length", description="Default length when creating a new dimension object", default=1.0, min=0.001, soft_max=1000.0)
    annotation_on_top: BoolProperty(name="Annotations On Top", description="Draw annotation lines over geometry in viewport", default=True, update=_update_redraw)
    annotation_line_color: FloatVectorProperty(name="Annotation Line Color", description="Line color for annotation preview and export", subtype="COLOR", size=4, min=0.0, max=1.0, default=(1.0, 0.85, 0.1, 0.95), update=_update_redraw)
    annotation_text_color: FloatVectorProperty(name="Annotation Text Color", description="Text color for annotation preview and export", subtype="COLOR", size=4, min=0.0, max=1.0, default=(1.0, 0.95, 0.75, 1.0), update=_update_redraw)
    show_annotation_preview: BoolProperty(name="Show Annotation Preview", description="Show dimensions and notes in viewport", default=True, update=_update_redraw)
    preview_only_camera_view: BoolProperty(name="Preview Only Camera View", description="Show preview only when looking through the configured camera", default=True, update=_update_redraw)
    viewport_text_size: IntProperty(name="Viewport Text Size", description="Text size for viewport preview", default=14, min=8, max=72)
    camera_obj: PointerProperty(name="Camera", type=bpy.types.Object, description="Projection camera", poll=lambda _self, obj: obj.type == "CAMERA", update=_update_redraw)


class MESHCUT_UL_annotations(UIList):
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        icon = "FONT_DATA"
        if item.annotation_type == "DIMENSION":
            icon = "DRIVER_DISTANCE"
        elif item.annotation_type == "ANGLE":
            icon = "DRIVER_ROTATIONAL_DIFFERENCE"
        elif item.annotation_type == "ARC":
            icon = "MOD_CURVE"
        layout.label(text=(item.text if item.text else item.name), icon=icon)


class MESHCUT_OT_add_text_annotation(Operator):
    bl_idname = "meshcut.add_text_annotation"
    bl_label = "Add Text Annotation"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        settings = scene.meshcut_settings
        ann = scene.meshcut_annotations.add()
        ann.annotation_type = "TEXT"
        ann.text = settings.new_text_label.strip() or "Note"
        ann.name = f"Text {len(scene.meshcut_annotations)}"
        cursor = scene.cursor.location.copy()
        ann.p1 = cursor
        ann.p2 = cursor
        ann.p3 = cursor
        obj = _create_annotation_empty(scene, f"MC_Text_{len(scene.meshcut_annotations):03d}", cursor)
        ann.p1_object_name = obj.name
        ann.p2_object_name = ""
        ann.p3_object_name = ""
        scene.meshcut_annotation_index = len(scene.meshcut_annotations) - 1
        self.report({"INFO"}, "Text annotation created.")
        return {"FINISHED"}


class MESHCUT_OT_add_dimension_annotation(Operator):
    bl_idname = "meshcut.add_dimension_annotation"
    bl_label = "Add Dimension Object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        settings = scene.meshcut_settings
        camera = settings.camera_obj or scene.camera
        cursor = scene.cursor.location.copy()
        if camera and camera.type == "CAMERA":
            right, _up, _forward = _camera_axes(camera)
            p1 = _project_world_to_camera_cut_plane(cursor, camera, settings)
            p2 = p1 + (right * settings.dimension_default_length)
        else:
            p1 = cursor
            p2 = cursor + Vector((settings.dimension_default_length, 0.0, 0.0))

        ann = scene.meshcut_annotations.add()
        ann.annotation_type = "DIMENSION"
        ann.text = settings.new_dim_label.strip()
        ann.name = f"Dim {len(scene.meshcut_annotations)}"
        ann.p1 = p1
        ann.p2 = p2
        ann.p3 = p2
        obj1 = _create_annotation_empty(scene, f"MC_Dim_A_{len(scene.meshcut_annotations):03d}", Vector(p1))
        obj2 = _create_annotation_empty(scene, f"MC_Dim_B_{len(scene.meshcut_annotations):03d}", Vector(p2))
        ann.p1_object_name = obj1.name
        ann.p2_object_name = obj2.name
        ann.p3_object_name = ""
        scene.meshcut_annotation_index = len(scene.meshcut_annotations) - 1
        self.report({"INFO"}, "Dimension object created. Move A/B empties to set endpoints.")
        return {"FINISHED"}


class MESHCUT_OT_measure_dimension(Operator):
    bl_idname = "meshcut.measure_dimension"
    bl_label = "Measure In Viewport"
    bl_description = "Click in the viewport to create a 2D camera-aligned measurement on the selected cut plane"
    bl_options = {"REGISTER", "UNDO"}

    dimension_mode: EnumProperty(
        name="Mode",
        items=[
            ("LINEAR", "Linear", "Measure a straight 2-point distance"),
            ("ALIGNED", "Aligned", "Measure the direct distance between two points"),
            ("HORIZONTAL", "Horizontal", "Constrain the second point to the camera horizontal axis"),
            ("VERTICAL", "Vertical", "Constrain the second point to the camera vertical axis"),
            ("ARC", "Arc", "Click start, point on arc, and end"),
        ],
        default="LINEAR",
    )

    def _camera(self, context):
        settings = context.scene.meshcut_settings
        return settings.camera_obj or context.scene.camera

    def _required_points(self):
        return 3 if self.dimension_mode == "ARC" else 2

    def _current_points(self):
        if self._hover is None:
            return list(self._points)
        points = list(self._points) + [self._hover]
        if self.dimension_mode in {"HORIZONTAL", "VERTICAL"} and len(points) >= 2:
            points[1] = _constrain_dimension_point(points[0], points[1], self.dimension_mode, self._camera_obj)
        return points

    def _update_preview(self, context):
        points = self._current_points()
        settings = context.scene.meshcut_settings
        scene = context.scene
        segments = []
        label_pos = None
        label = ""

        if self.dimension_mode == "ARC" and len(points) >= 2:
            if len(points) >= 3:
                arc_points, label_pos, arc_length = _arc_camera_points(self._camera_obj, settings, points[0], points[1], points[2])
                segments = _segments_from_points(arc_points)
                label = _format_length(scene, arc_length)
            else:
                segments = [(points[0], points[1])]
                label_pos = (points[0] + points[1]) * 0.5
                label = _format_length(scene, (points[1] - points[0]).length)
        elif len(points) >= 2:
            p1, p2 = points[0], points[1]
            segments = [(p1, p2)]
            label_pos = (p1 + p2) * 0.5
            label = _format_length(scene, (p2 - p1).length)

        _DRAW_DIMENSION_PREVIEW["active"] = bool(segments)
        _DRAW_DIMENSION_PREVIEW["segments"] = segments
        _DRAW_DIMENSION_PREVIEW["label_pos"] = label_pos
        _DRAW_DIMENSION_PREVIEW["label"] = label
        _tag_redraw_view3d()

    def _finish(self, context):
        points = self._current_points()[: self._required_points()]
        if len(points) < self._required_points():
            _clear_dimension_preview()
            return {"CANCELLED"}

        scene = context.scene
        settings = scene.meshcut_settings
        ann = scene.meshcut_annotations.add()
        ann.annotation_type = "ARC" if self.dimension_mode == "ARC" else "DIMENSION"
        ann.text = settings.new_dim_label.strip()
        ann.name = f"{'Arc' if self.dimension_mode == 'ARC' else 'Dim'} {len(scene.meshcut_annotations)}"
        ann.p1 = points[0]
        ann.p2 = points[1]
        ann.p3 = points[2] if self.dimension_mode == "ARC" else points[1]
        ann.p1_object_name = ""
        ann.p2_object_name = ""
        ann.p3_object_name = ""
        scene.meshcut_annotation_index = len(scene.meshcut_annotations) - 1
        _clear_dimension_preview()
        self.report({"INFO"}, "2D camera-aligned measurement created.")
        return {"FINISHED"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            _clear_dimension_preview()
            return {"CANCELLED"}

        if event.type == "MOUSEMOVE":
            self._hover = _mouse_to_camera_cut_plane(context, event, self._camera_obj, context.scene.meshcut_settings)
            self._update_preview(context)
            return {"RUNNING_MODAL"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            point = _mouse_to_camera_cut_plane(context, event, self._camera_obj, context.scene.meshcut_settings)
            if point is None:
                return {"RUNNING_MODAL"}
            self._hover = point
            current = self._current_points()
            self._points.append(current[-1])
            if len(self._points) >= self._required_points():
                return self._finish(context)
            self._hover = None
            self._update_preview(context)
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"ERROR"}, "Run the measure tool from a 3D Viewport.")
            return {"CANCELLED"}

        camera = self._camera(context)
        if not camera or camera.type != "CAMERA":
            self.report({"ERROR"}, "Pick a valid camera in Mesh Cut > Camera.")
            return {"CANCELLED"}

        self._camera_obj = camera
        self._points = []
        self._hover = _mouse_to_camera_cut_plane(context, event, camera, context.scene.meshcut_settings)
        context.window_manager.modal_handler_add(self)
        self._update_preview(context)
        return {"RUNNING_MODAL"}


class MESHCUT_OT_add_angle_annotation(Operator):
    bl_idname = "meshcut.add_angle_annotation"
    bl_label = "Add Angle Dimension"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        settings = scene.meshcut_settings
        p1, p2, p3, err = _get_angle_points_from_context(context)
        if err:
            cursor = scene.cursor.location.copy()
            p1 = cursor + Vector((settings.dimension_default_length, 0.0, 0.0))
            p2 = cursor
            p3 = cursor + Vector((0.0, settings.dimension_default_length, 0.0))

        ann = scene.meshcut_annotations.add()
        ann.annotation_type = "ANGLE"
        ann.text = settings.new_dim_label.strip()
        ann.name = f"Angle {len(scene.meshcut_annotations)}"
        ann.p1 = p1
        ann.p2 = p2
        ann.p3 = p3
        obj1 = _create_annotation_empty(scene, f"MC_Ang_A_{len(scene.meshcut_annotations):03d}", Vector(p1))
        obj2 = _create_annotation_empty(scene, f"MC_Ang_B_{len(scene.meshcut_annotations):03d}", Vector(p2))
        obj3 = _create_annotation_empty(scene, f"MC_Ang_C_{len(scene.meshcut_annotations):03d}", Vector(p3))
        ann.p1_object_name = obj1.name
        ann.p2_object_name = obj2.name
        ann.p3_object_name = obj3.name
        scene.meshcut_annotation_index = len(scene.meshcut_annotations) - 1
        self.report({"INFO"}, "Angle dimension created. Move A/B/C empties (B is the vertex).")
        return {"FINISHED"}


class MESHCUT_OT_remove_annotation(Operator):
    bl_idname = "meshcut.remove_annotation"
    bl_label = "Remove Annotation"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        idx = scene.meshcut_annotation_index
        if idx < 0 or idx >= len(scene.meshcut_annotations):
            self.report({"ERROR"}, "No annotation selected.")
            return {"CANCELLED"}
        ann = scene.meshcut_annotations[idx]
        _remove_annotation_object(ann.p1_object_name)
        _remove_annotation_object(ann.p2_object_name)
        _remove_annotation_object(ann.p3_object_name)
        scene.meshcut_annotations.remove(idx)
        scene.meshcut_annotation_index = min(idx, max(0, len(scene.meshcut_annotations) - 1))
        self.report({"INFO"}, "Annotation removed.")
        return {"FINISHED"}


class MESHCUT_OT_clear_annotations(Operator):
    bl_idname = "meshcut.clear_annotations"
    bl_label = "Clear Annotations"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        for ann in scene.meshcut_annotations:
            _remove_annotation_object(ann.p1_object_name)
            _remove_annotation_object(ann.p2_object_name)
            _remove_annotation_object(ann.p3_object_name)
        scene.meshcut_annotations.clear()
        scene.meshcut_annotation_index = 0
        self.report({"INFO"}, "All annotations cleared.")
        return {"FINISHED"}

class MESHCUT_OT_create_camera(Operator):
    bl_idname = "meshcut.create_camera"
    bl_label = "Create Mesh Cut Camera"
    bl_description = "Create an orthographic camera aligned for plan/elevation"
    bl_options = {"REGISTER", "UNDO"}

    view_type: EnumProperty(name="Type", items=[("PLAN", "Plan", "Top view"), ("ELEVATION_FRONT", "Elevation Front", "Front view"), ("ELEVATION_RIGHT", "Elevation Right", "Right view"), ("ELEVATION_LEFT", "Elevation Left", "Left view"), ("ELEVATION_BACK", "Elevation Back", "Back view")], default="PLAN")
    distance: FloatProperty(name="Distance", default=20.0, min=0.1, soft_max=10000.0)
    ortho_scale: FloatProperty(name="Ortho Scale", default=50.0, min=0.01, soft_max=10000.0)

    def execute(self, context):
        cam_data = bpy.data.cameras.new(name=f"MeshCut_{self.view_type}")
        cam_data.type = "ORTHO"
        cam_data.ortho_scale = self.ortho_scale
        cam_obj = bpy.data.objects.new(cam_data.name, cam_data)
        cam_collection = _get_or_create_meshcut_camera_collection(context.scene)
        cam_collection.objects.link(cam_obj)

        center = context.scene.cursor.location.copy()
        if self.view_type == "PLAN":
            direction = Vector((0.0, 0.0, 1.0)); rotation = (0.0, 0.0, 0.0)
        elif self.view_type == "ELEVATION_FRONT":
            direction = Vector((0.0, -1.0, 0.0)); rotation = (math.radians(90.0), 0.0, 0.0)
        elif self.view_type == "ELEVATION_RIGHT":
            direction = Vector((1.0, 0.0, 0.0)); rotation = (math.radians(90.0), 0.0, math.radians(90.0))
        elif self.view_type == "ELEVATION_LEFT":
            direction = Vector((-1.0, 0.0, 0.0)); rotation = (math.radians(90.0), 0.0, math.radians(-90.0))
        else:
            direction = Vector((0.0, 1.0, 0.0)); rotation = (math.radians(90.0), 0.0, math.radians(180.0))

        cam_obj.location = center + direction * self.distance
        cam_obj.rotation_euler = rotation
        context.scene.camera = cam_obj
        context.scene.meshcut_settings.camera_obj = cam_obj
        _tag_redraw_view3d()
        self.report({"INFO"}, f"Camera created: {cam_obj.name}")
        return {"FINISHED"}


class MESHCUT_OT_export_svg(Operator):
    bl_idname = "meshcut.export_svg"
    bl_label = "Export SVG"
    bl_options = {"REGISTER"}
    filepath: StringProperty(subtype="FILE_PATH")
    filename_ext = ".svg"
    filter_glob: StringProperty(default="*.svg", options={"HIDDEN"})

    def execute(self, context):
        settings = (getattr(context, "scene", None) or bpy.context.scene).meshcut_settings
        progress = _ProgressReporter(context, "Mesh Cut SVG Export")
        try:
            progress.begin("Collecting mesh geometry")
            segments, points, anno_lines, anno_texts, budget = _collect_segments(context, progress=progress)
            progress.update(0.99, "Writing SVG file", force=True)
            _write_svg(
                self.filepath,
                segments,
                points,
                anno_lines,
                anno_texts,
                settings.svg_scale,
                settings.svg_margin,
                settings.svg_text_size,
                settings.annotation_line_color,
                settings.annotation_text_color,
            )
            if budget["enabled"] and budget["limit_hit"]:
                if budget["force_visible_on_limit"]:
                    mode = "always finish export"
                elif budget["fallback_visible"]:
                    mode = "fallback visibility"
                else:
                    mode = "hidden remainder"
                self.report(
                    {"WARNING"},
                    f"Performance guard hit ({budget['ray_casts']} ray casts). Export mode: {mode}.",
                )
            progress.update(1.0, "SVG export complete", force=True)
            self.report({"INFO"}, f"SVG exported: {self.filepath}")
            return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            progress.end()

    def invoke(self, context, _event):
        if not self.filepath:
            blend_name = Path(bpy.data.filepath).stem or "untitled"
            self.filepath = str(Path.home() / f"{_safe_name(blend_name)}_meshcut.svg")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class MESHCUT_OT_export_dxf(Operator):
    bl_idname = "meshcut.export_dxf"
    bl_label = "Export DXF"
    bl_options = {"REGISTER"}
    filepath: StringProperty(subtype="FILE_PATH")
    filename_ext = ".dxf"
    filter_glob: StringProperty(default="*.dxf", options={"HIDDEN"})

    def execute(self, context):
        settings = (getattr(context, "scene", None) or bpy.context.scene).meshcut_settings
        progress = _ProgressReporter(context, "Mesh Cut DXF Export")
        try:
            progress.begin("Collecting mesh geometry")
            segments, points, anno_lines, anno_texts, budget = _collect_segments(context, progress=progress)
            progress.update(0.99, "Writing DXF file", force=True)
            _write_dxf(
                self.filepath,
                segments,
                points,
                anno_lines,
                anno_texts,
                settings.dxf_text_height,
                settings.annotation_line_color,
                settings.annotation_text_color,
            )
            if budget["enabled"] and budget["limit_hit"]:
                if budget["force_visible_on_limit"]:
                    mode = "always finish export"
                elif budget["fallback_visible"]:
                    mode = "fallback visibility"
                else:
                    mode = "hidden remainder"
                self.report(
                    {"WARNING"},
                    f"Performance guard hit ({budget['ray_casts']} ray casts). Export mode: {mode}.",
                )
            progress.update(1.0, "DXF export complete", force=True)
            self.report({"INFO"}, f"DXF exported: {self.filepath}")
            return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            progress.end()

    def invoke(self, context, _event):
        if not self.filepath:
            blend_name = Path(bpy.data.filepath).stem or "untitled"
            self.filepath = str(Path.home() / f"{_safe_name(blend_name)}_meshcut.dxf")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class MESHCUT_PT_panel(Panel):
    bl_label = "Mesh Cut Plan/Elevation"
    bl_idname = "MESHCUT_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Mesh Cut"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.meshcut_settings

        col = layout.column(align=True)
        col.label(text="Camera")
        col.prop(settings, "camera_obj")

        row = col.row(align=True)
        op = row.operator("meshcut.create_camera", text="Plan"); op.view_type = "PLAN"
        op = row.operator("meshcut.create_camera", text="Front"); op.view_type = "ELEVATION_FRONT"

        row = col.row(align=True)
        op = row.operator("meshcut.create_camera", text="Right"); op.view_type = "ELEVATION_RIGHT"
        op = row.operator("meshcut.create_camera", text="Left"); op.view_type = "ELEVATION_LEFT"

        col.separator(); col.label(text="Depth Filter")
        col.prop(settings, "show_depth_overlay")
        col.prop(settings, "depth_near")
        col.prop(settings, "depth_far")
        col.prop(settings, "export_section_cuts")
        if settings.export_section_cuts:
            col.prop(settings, "export_cut_hatches")
            if settings.export_cut_hatches:
                col.prop(settings, "hatch_spacing")
                col.prop(settings, "hatch_angle")

        col.separator(); col.label(text="Visibility")
        col.prop(settings, "visible_only")
        col.prop(settings, "require_cython_backend")
        status_text = "Compiled backend: available" if cython_backend_available() else "Compiled backend: missing"
        col.label(text=status_text, icon="CHECKMARK" if cython_backend_available() else "ERROR")
        col.prop(settings, "performance_guard")
        if settings.performance_guard:
            col.prop(settings, "max_ray_casts")
            col.prop(settings, "ensure_finish_on_budget")
            col.prop(settings, "budget_fallback_visible")
        col.prop(settings, "visibility_samples")

        col.separator(); col.label(text="Collection")
        col.prop(settings, "use_selected_only")
        col.prop(settings, "export_vertices")

        col.separator(); col.label(text="Annotations")
        col.prop(settings, "show_annotation_preview")
        col.prop(settings, "preview_only_camera_view")
        col.prop(settings, "annotation_on_top")
        col.prop(settings, "annotation_line_color")
        col.prop(settings, "annotation_text_color")
        col.prop(settings, "viewport_text_size")
        col.prop(settings, "new_text_label")
        col.operator("meshcut.add_text_annotation", icon="FONT_DATA")
        col.prop(settings, "new_dim_label")
        col.prop(settings, "dimension_mode")
        op = col.operator("meshcut.measure_dimension", text="Measure In Viewport", icon="EMPTY_ARROWS")
        op.dimension_mode = settings.dimension_mode
        col.prop(settings, "dimension_default_length")
        col.operator("meshcut.add_dimension_annotation", icon="DRIVER_DISTANCE")
        col.operator("meshcut.add_angle_annotation", icon="DRIVER_ROTATIONAL_DIFFERENCE")
        col.template_list("MESHCUT_UL_annotations", "", scene, "meshcut_annotations", scene, "meshcut_annotation_index", rows=4)

        row = col.row(align=True)
        row.operator("meshcut.remove_annotation", icon="X")
        row.operator("meshcut.clear_annotations", icon="TRASH")

        col.separator(); col.label(text="Export")
        col.prop(settings, "svg_scale")
        col.prop(settings, "svg_margin")
        col.prop(settings, "svg_text_size")
        col.prop(settings, "dxf_text_height")
        col.operator("meshcut.export_svg", icon="EXPORT")
        col.operator("meshcut.export_dxf", icon="EXPORT")


classes = (
    MESHCUT_PG_annotation,
    MESHCUT_PG_settings,
    MESHCUT_UL_annotations,
    MESHCUT_OT_add_text_annotation,
    MESHCUT_OT_add_dimension_annotation,
    MESHCUT_OT_measure_dimension,
    MESHCUT_OT_add_angle_annotation,
    MESHCUT_OT_remove_annotation,
    MESHCUT_OT_clear_annotations,
    MESHCUT_OT_create_camera,
    MESHCUT_OT_export_svg,
    MESHCUT_OT_export_dxf,
    MESHCUT_PT_panel,
)


def register():
    global _DRAW_HANDLE_VIEW, _DRAW_HANDLE_TEXT
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.meshcut_settings = PointerProperty(type=MESHCUT_PG_settings)
    bpy.types.Scene.meshcut_annotations = CollectionProperty(type=MESHCUT_PG_annotation)
    bpy.types.Scene.meshcut_annotation_index = IntProperty(default=0)

    if _DRAW_HANDLE_VIEW is None:
        _DRAW_HANDLE_VIEW = bpy.types.SpaceView3D.draw_handler_add(_draw_view_overlay, (), "WINDOW", "POST_VIEW")
    if _DRAW_HANDLE_TEXT is None:
        _DRAW_HANDLE_TEXT = bpy.types.SpaceView3D.draw_handler_add(_draw_annotations_overlay_text, (), "WINDOW", "POST_PIXEL")


def unregister():
    global _DRAW_HANDLE_VIEW, _DRAW_HANDLE_TEXT
    if _DRAW_HANDLE_VIEW is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_DRAW_HANDLE_VIEW, "WINDOW")
        _DRAW_HANDLE_VIEW = None
    if _DRAW_HANDLE_TEXT is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_DRAW_HANDLE_TEXT, "WINDOW")
        _DRAW_HANDLE_TEXT = None

    if hasattr(bpy.types.Scene, "meshcut_annotation_index"):
        del bpy.types.Scene.meshcut_annotation_index
    if hasattr(bpy.types.Scene, "meshcut_annotations"):
        del bpy.types.Scene.meshcut_annotations
    if hasattr(bpy.types.Scene, "meshcut_settings"):
        del bpy.types.Scene.meshcut_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
